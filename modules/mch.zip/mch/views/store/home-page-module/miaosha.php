<?php
defined('YII_RUN') or exit('Access Denied');
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/8/31
 * Time: 18:05
 */
?>
<div class="home-block">
    <div class="block-content">
        <div class="block-name">秒杀</div>
    </div>
    <img class="block-img" src="<?= Yii::$app->request->baseUrl ?>/statics/images/miaosha-bg.png">
</div>