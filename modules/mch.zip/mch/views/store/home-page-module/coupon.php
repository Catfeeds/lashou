<?php
defined('YII_RUN') or exit('Access Denied');
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/8/31
 * Time: 18:05
 */
?>
<div class="home-block">
    <div class="block-content">
        <div class="block-name">领券中心</div>
    </div>
    <img class="block-img" src="<?= Yii::$app->request->baseUrl ?>/statics/images/coupon-bg.png" style="width: 100%;height: auto">
</div>