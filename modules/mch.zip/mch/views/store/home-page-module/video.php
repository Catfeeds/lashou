<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/22
 * Time: 14:55
 */
defined('YII_RUN') or exit('Access Denied');
?>
<div class="home-block">
    <div class="block-content">
        <div class="block-name">视频</div>
    </div>
    <img class="block-img" src="<?= Yii::$app->request->baseUrl ?>/statics/images/video.png">
</div>