<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/6
 * Time: 9:30
 */
defined('YII_RUN') or exit('Access Denied');
?>
<div class="home-block">
    <div class="block-content">
        <div class="block-name">公告</div>
    </div>
    <img class="block-img" src="<?= Yii::$app->request->baseUrl ?>/statics/images/notice-bg.png">
</div>
